"""Manual Phase 1 test run: ``python -m deskmate.zaza``.

Starts the agent, prints events to the console as they're written (per the
Phase 1 "local console/debug output is acceptable" allowance), and stops
cleanly on Ctrl+C. Component health (keyboard/mouse hooks, session-lock
watcher, foreground-window watcher, SQLite storage) is printed at startup
and again whenever any component changes state, so a failed hook is visible
instead of looking like an idle user. No network, no PostgreSQL, no Google Sheets, no
dashboard — this is the local-only agent by itself.
"""

from __future__ import annotations

import time

from .agent import ActivityAgent
from .config import from_env
from .health import ComponentHealth


def main() -> None:
    config = from_env()
    agent = ActivityAgent(config)

    def on_health_change(entry: ComponentHealth) -> None:
        suffix = f" - {entry.detail}" if entry.detail else ""
        print(
            f"[health] {entry.component}: {entry.state.value}{suffix} "
            f"(overall {agent.health.overall().value})"
        )

    agent.health.set_on_change(on_health_change)
    print(
        f"ZaZa activity agent (Phase 1) — employee={config.employee_id} "
        f"device={config.device_id} idle_threshold={config.idle_threshold_seconds}s "
        f"db={config.db_path}"
    )
    print("Tracking: active app/window, keyboard/mouse presence, idle, lock/unlock.")
    print("NOT tracking: screenshots, OCR, typed text, clipboard, audio, video.")
    print("Press Ctrl+C to stop.\n")
    agent.start()
    time.sleep(1)  # let the hook/watcher threads report in before the summary
    print(agent.health.format_table() + "\n")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        agent.stop()


if __name__ == "__main__":
    main()
