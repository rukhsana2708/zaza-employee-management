"""Phase 1 agent configuration.

Only the settings Phase 1 needs: who/what is being tracked, the idle
threshold, and where the local SQLite queue lives. No network, schedule, or
server settings here yet — those arrive in later phases.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from . import paths

DEFAULT_IDLE_THRESHOLD_SECONDS = 300  # 5 minutes, per spec
DEFAULT_TICK_SECONDS = 10  # how often the sampler writes an ACTIVITY row


@dataclass(frozen=True)
class AgentConfig:
    employee_id: str = "unassigned"
    device_id: str = "unassigned-device"
    idle_threshold_seconds: int = DEFAULT_IDLE_THRESHOLD_SECONDS
    tick_seconds: int = DEFAULT_TICK_SECONDS
    db_path: str = field(default_factory=lambda: str(paths.db_path()))

    def __post_init__(self) -> None:
        if self.idle_threshold_seconds <= 0:
            raise ValueError("idle_threshold_seconds must be positive")
        if self.tick_seconds <= 0:
            raise ValueError("tick_seconds must be positive")


def from_env() -> AgentConfig:
    """Build config from environment variables, falling back to defaults.

    ``ZAZA_EMPLOYEE_ID``, ``ZAZA_DEVICE_ID``, ``ZAZA_IDLE_THRESHOLD_SECONDS``,
    ``ZAZA_TICK_SECONDS``. All optional — this is Phase 1 local-only config,
    not the eventual central-server-issued schedule/config.
    """
    kwargs: dict[str, object] = {}
    if v := os.environ.get("ZAZA_EMPLOYEE_ID"):
        kwargs["employee_id"] = v
    if v := os.environ.get("ZAZA_DEVICE_ID"):
        kwargs["device_id"] = v
    if v := os.environ.get("ZAZA_IDLE_THRESHOLD_SECONDS"):
        kwargs["idle_threshold_seconds"] = int(v)
    if v := os.environ.get("ZAZA_TICK_SECONDS"):
        kwargs["tick_seconds"] = int(v)
    return AgentConfig(**kwargs)
