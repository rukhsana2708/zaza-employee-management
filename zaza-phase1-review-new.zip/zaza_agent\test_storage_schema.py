"""Storage-layer privacy guards: the schema has no column for prohibited
content, and insert_event's fixed keyword signature cannot be used to smuggle
any in, even if a caller tries."""

from __future__ import annotations

import sqlite3

import pytest

from deskmate.zaza.storage import ActivityStore


@pytest.fixture
def store(tmp_path):
    db_file = tmp_path / "activity.db"
    s = ActivityStore(db_file)
    yield s
    s.close()


def test_schema_has_no_prohibited_columns(store):
    conn: sqlite3.Connection = store._conn  # inspecting the real schema, not a mock
    cols = {row["name"].lower() for row in conn.execute("PRAGMA table_info(activity_events)").fetchall()}
    expected = {"id", "ts", "event_type", "app_name", "window_title", "keyboard_active", "mouse_active", "idle"}
    assert cols == expected
    prohibited_exact_names = {
        "text", "key_char", "key_code", "clipboard_text", "clipboard",
        "screenshot", "screenshot_path", "frame", "image", "ocr_text",
        "audio", "video", "password",
    }
    assert cols.isdisjoint(prohibited_exact_names)


def test_insert_event_rejects_unknown_keyword_clipboard_text(store):
    with pytest.raises(TypeError):
        store.insert_event(event_type="ACTIVITY", clipboard_text="something copied")  # type: ignore[call-arg]


def test_insert_event_rejects_unknown_keyword_key_char(store):
    with pytest.raises(TypeError):
        store.insert_event(event_type="ACTIVITY", key_char="a")  # type: ignore[call-arg]


def test_insert_event_rejects_unknown_keyword_screenshot_path(store):
    with pytest.raises(TypeError):
        store.insert_event(event_type="ACTIVITY", screenshot_path="/tmp/shot.png")  # type: ignore[call-arg]


def test_insert_event_rejects_unknown_event_type(store):
    with pytest.raises(ValueError):
        store.insert_event(event_type="SCREENSHOT")


def test_insert_and_read_back_only_allowed_fields(store):
    store.insert_event(
        event_type="ACTIVITY",
        app_name="notepad.exe",
        window_title="Untitled - Notepad",
        keyboard_active=True,
        mouse_active=False,
        idle=False,
    )
    rows = store.recent_events(limit=1)
    assert len(rows) == 1
    row = rows[0]
    assert row["event_type"] == "ACTIVITY"
    assert row["app_name"] == "notepad.exe"
    assert row["keyboard_active"] == 1
    assert row["mouse_active"] == 0
    assert set(row.keys()) == {
        "id", "ts", "event_type", "app_name", "window_title", "keyboard_active", "mouse_active", "idle",
    }
