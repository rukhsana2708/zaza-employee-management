"""Phase 1 orchestrator: wires the window watcher, input hooks, idle
tracking, lock/unlock watcher, and local SQLite store into one agent.

Every component reports into ``self.health`` (see ``health.py``). If a
keyboard or mouse hook is in ERROR, the agent stops treating "no input seen"
as inactivity: ACTIVITY rows record NULL (unknown) for the affected flag and
for ``idle``, and no IDLE/CONTINUE transitions are emitted.

``tick()`` is the core sampling step and is deliberately synchronous/pure
enough to call directly from tests. ``start()``/``stop()`` additionally run
the real Windows hooks and a background timer thread for live/manual use.
"""

from __future__ import annotations

import sqlite3
import threading

from .config import AgentConfig
from .health import (
    KEYBOARD_HOOK,
    MOUSE_HOOK,
    STORAGE,
    WINDOW_WATCH,
    HealthRegistry,
    HealthState,
)
from .logger import get
from .recorder import ActivityRecorder
from .session_lock import SessionLockWatcher
from .storage import ActivityStore
from .window_watch import ForegroundProbe, WindowChangeTracker, get_foreground_window

logger = get("agent")


class ActivityAgent:
    def __init__(
        self,
        config: AgentConfig,
        *,
        store: ActivityStore | None = None,
        window_probe: ForegroundProbe = get_foreground_window,
        health: HealthRegistry | None = None,
    ) -> None:
        self.config = config
        self.health = health or HealthRegistry()
        try:
            self.store = store or ActivityStore(config.db_path)
            self.store.ping()
        except sqlite3.Error as exc:
            self.health.set(STORAGE, HealthState.ERROR, f"cannot open database: {exc}")
            raise
        self.health.set(STORAGE, HealthState.HEALTHY, "ready")
        self.recorder = ActivityRecorder(idle_threshold_seconds=config.idle_threshold_seconds)
        self._window_tracker = WindowChangeTracker(probe=window_probe)
        self._was_idle = False
        self._input_untrusted_logged = False
        self._timer_thread: threading.Thread | None = None
        self._stop = threading.Event()

        self._input_hooks = None
        self._lock_watcher = SessionLockWatcher(on_event=self._on_session_event, health=self.health)

    def health_status(self) -> HealthState:
        return self.health.overall()

    def _insert(self, **kwargs) -> None:  # noqa: ANN003
        try:
            self.store.insert_event(**kwargs)
        except sqlite3.Error as exc:
            self.health.set(STORAGE, HealthState.ERROR, f"write failed: {exc}")
            raise
        self.health.set(STORAGE, HealthState.HEALTHY, "ready")

    # ─── one sampling step — called by the timer thread, or directly in tests ──
    def tick(self) -> None:
        try:
            changed = self._window_tracker.poll()
        except Exception as exc:  # noqa: BLE001
            changed = None
            self.health.set(WINDOW_WATCH, HealthState.ERROR, f"foreground probe failed: {exc}")
            logger.warning("foreground probe failed: %s", exc)
        else:
            self.health.set(WINDOW_WATCH, HealthState.HEALTHY, "polling")
        if changed is not None:
            self._insert(
                event_type="APP_CHANGE",
                app_name=changed.app_name,
                window_title=changed.window_title,
            )
            logger.info("APP_CHANGE app=%s title=%s", changed.app_name, changed.window_title)

        keyboard_active, mouse_active = self.recorder.snapshot_and_reset()
        # A failed hook looks exactly like an idle user, so its flag becomes
        # NULL ("unknown") rather than False.
        if self.health.get(KEYBOARD_HOOK).state == HealthState.ERROR:
            keyboard_active = None
        if self.health.get(MOUSE_HOOK).state == HealthState.ERROR:
            mouse_active = None
        input_trustworthy = self.health.input_trustworthy()
        is_idle = self.recorder.is_idle() if input_trustworthy else None

        self._insert(
            event_type="ACTIVITY",
            keyboard_active=keyboard_active,
            mouse_active=mouse_active,
            idle=is_idle,
        )
        logger.info(
            "ACTIVITY keyboard=%s mouse=%s idle=%s", keyboard_active, mouse_active, is_idle
        )

        if not input_trustworthy:
            if not self._input_untrusted_logged:
                logger.warning(
                    "input hook ERROR — idle status unknown, IDLE/CONTINUE suppressed (health: %s)",
                    self.health.overall().value,
                )
                self._input_untrusted_logged = True
            return
        self._input_untrusted_logged = False

        if is_idle and not self._was_idle:
            self._insert(event_type="IDLE")
            logger.info("IDLE (idle for >= %ss)", self.config.idle_threshold_seconds)
        elif not is_idle and self._was_idle:
            self._insert(event_type="CONTINUE")
            logger.info("CONTINUE (activity resumed)")
        self._was_idle = is_idle

    def _on_session_event(self, name: str) -> None:
        self._insert(event_type=name)
        logger.info("%s", name)

    # ─── real run loop (Windows hooks + periodic sampler) ──────────────────
    def start(self) -> None:
        if self._input_hooks is None:
            from .input_hooks import ZazaInputHooks  # noqa: PLC0415

            self._input_hooks = ZazaInputHooks(self.recorder, health=self.health)
        self._input_hooks.start()
        self._lock_watcher.start()
        self._stop.clear()
        self._timer_thread = threading.Thread(target=self._run_timer, name="ZazaAgentTimer", daemon=True)
        self._timer_thread.start()
        logger.info(
            "ActivityAgent started (employee=%s device=%s idle_threshold=%ss tick=%ss)",
            self.config.employee_id,
            self.config.device_id,
            self.config.idle_threshold_seconds,
            self.config.tick_seconds,
        )

    def stop(self) -> None:
        self._stop.set()
        if self._timer_thread:
            self._timer_thread.join(timeout=self.config.tick_seconds + 2.0)
            self._timer_thread = None
        if self._input_hooks:
            self._input_hooks.stop()
        self._lock_watcher.stop()
        self.health.set(WINDOW_WATCH, HealthState.DEGRADED, "stopped")
        logger.info("ActivityAgent stopped")

    def _run_timer(self) -> None:
        while not self._stop.is_set():
            try:
                self.tick()
            except Exception as exc:  # noqa: BLE001
                logger.warning("tick failed: %s", exc)
            self._stop.wait(self.config.tick_seconds)
