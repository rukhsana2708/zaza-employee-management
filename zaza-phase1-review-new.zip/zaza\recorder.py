"""In-memory keyboard/mouse activity presence tracking.

This is the single place that receives "a key went down" / "a mouse button,
wheel, or move happened" signals. It never receives — and has no parameter
through which it *could* receive — which key, what text, or clipboard/screen
content. Callers can only say "activity happened," nothing else.
"""

from __future__ import annotations

import threading
import time


class ActivityRecorder:
    """Thread-safe boolean activity presence + idle-threshold tracking."""

    def __init__(self, *, idle_threshold_seconds: int, clock=time.monotonic) -> None:
        self.idle_threshold_seconds = idle_threshold_seconds
        self._clock = clock
        self._lock = threading.Lock()
        now = self._clock()
        self._last_keyboard_at: float | None = None
        self._last_mouse_at: float | None = None
        self._last_activity_at: float = now
        # Flags accumulated since the last snapshot() call — this is how the
        # sampler gets "did keyboard/mouse activity occur since I last looked"
        # without storing any per-event detail.
        self._keyboard_since_snapshot = False
        self._mouse_since_snapshot = False

    def record_keyboard(self) -> None:
        now = self._clock()
        with self._lock:
            self._last_keyboard_at = now
            self._last_activity_at = now
            self._keyboard_since_snapshot = True

    def record_mouse(self) -> None:
        now = self._clock()
        with self._lock:
            self._last_mouse_at = now
            self._last_activity_at = now
            self._mouse_since_snapshot = True

    def snapshot_and_reset(self) -> tuple[bool, bool]:
        """Return (keyboard_active, mouse_active) since the last call, then reset."""
        with self._lock:
            kb, mouse = self._keyboard_since_snapshot, self._mouse_since_snapshot
            self._keyboard_since_snapshot = False
            self._mouse_since_snapshot = False
            return kb, mouse

    def seconds_idle(self) -> float:
        with self._lock:
            last = self._last_activity_at
        return max(0.0, self._clock() - last)

    def is_idle(self) -> bool:
        return self.seconds_idle() >= self.idle_threshold_seconds
