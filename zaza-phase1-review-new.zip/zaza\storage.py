"""Local SQLite event queue for the ZaZa activity agent.

Separate database file from upstream DeskMate (see ``zaza/paths.py``) and a
separate, much smaller schema: one table, a fixed and narrow set of columns.
There is no column that could hold typed text, clipboard contents, a
screenshot, or audio/video — and :meth:`ActivityStore.insert_event` only
accepts the exact keyword arguments below, so a caller cannot smuggle extra
content through even by accident.
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Iterable
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import paths

SCHEMA_VERSION = 1

# Event vocabulary matches the Activity Log event set already documented in
# ARCHITECTURE.md (the subset relevant to a local, network-less Phase 1).
EVENT_TYPES = frozenset({"APP_CHANGE", "ACTIVITY", "IDLE", "CONTINUE", "LOCK", "UNLOCK"})

SCHEMA = """
CREATE TABLE IF NOT EXISTS activity_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    event_type TEXT NOT NULL,
    app_name TEXT,
    window_title TEXT,
    keyboard_active INTEGER,
    mouse_active INTEGER,
    idle INTEGER
);
CREATE INDEX IF NOT EXISTS idx_activity_events_ts ON activity_events(ts);

CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _dict_factory(cursor: sqlite3.Cursor, row: tuple) -> dict[str, Any]:
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


class ActivityStore:
    """One connection, serialized writes — same pattern as
    ``deskmate.db.manager.DatabaseManager``, but a separate file/schema."""

    def __init__(self, db_file: Path | str | None = None) -> None:
        paths.ensure_dirs()
        self.path = Path(db_file) if db_file else paths.db_path()
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = _dict_factory
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.execute(
                "INSERT OR IGNORE INTO schema_meta(key, value) VALUES ('schema_version', ?)",
                (str(SCHEMA_VERSION),),
            )

    def ping(self) -> None:
        """Cheap readiness probe; raises ``sqlite3.Error`` if the DB is unusable."""
        with self._lock:
            self._conn.execute("SELECT 1").fetchone()

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def insert_event(
        self,
        *,
        event_type: str,
        ts: str | None = None,
        app_name: str | None = None,
        window_title: str | None = None,
        keyboard_active: bool | None = None,
        mouse_active: bool | None = None,
        idle: bool | None = None,
    ) -> int:
        """Insert one activity event. Keyword-only, fixed parameter set — there
        is no argument here that could carry typed text, clipboard contents, a
        screenshot, or audio/video, so no caller can persist any of that even
        by mistake."""
        if event_type not in EVENT_TYPES:
            raise ValueError(f"unknown event_type: {event_type!r}")
        row_ts = ts or _now_iso()
        with self._lock:
            cur = self._conn.execute(
                """
                INSERT INTO activity_events
                    (ts, event_type, app_name, window_title, keyboard_active, mouse_active, idle)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    row_ts,
                    event_type,
                    app_name,
                    window_title,
                    None if keyboard_active is None else int(keyboard_active),
                    None if mouse_active is None else int(mouse_active),
                    None if idle is None else int(idle),
                ),
            )
            return int(cur.lastrowid)

    def recent_events(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            rows: Iterable[dict[str, Any]] = self._conn.execute(
                "SELECT * FROM activity_events ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return list(rows)

    def count_events(self) -> int:
        with self._lock:
            row = self._conn.execute("SELECT COUNT(*) AS n FROM activity_events").fetchone()
            return int(row["n"])
